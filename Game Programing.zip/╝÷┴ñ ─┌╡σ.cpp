#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>

void intro_game(void);
void horizontal_slide(int x, int y, char *c2);
void draw_rectangle(int r, int c);
void display_text(int count, int r_count, int score);
void game_control(int* r_c, int rnd[3], int *score);
void gotoxy(int x, int y);

int main(void)
{
   int count=0, score=0, rnd[3];
   int r_count=0;
   char *target[3]={"��", "��", "��"};
   srand(time(NULL));
   intro_game();
   do
   {
    system("cls");
    draw_rectangle(20, 41); 
    rnd[0]=rand()%35+4;
    gotoxy(rnd[0], 2);
    printf("%s", target[0]);
    rnd[1] = rand() % 35 + 4;
    	while (rnd[1] == rnd[0] || rnd[1] == (rnd[0] -1) || rnd[1] == (rnd[0]+1))
            {
            	rnd[1] = rand() % 35 + 4;
            }
    gotoxy(rnd[1], 2);
    printf("%s", target[1]);
    rnd[2] = rand() % 35 + 4;
    	while (rnd[2] == rnd[1] || rnd[2] == (rnd[1] -1) || rnd[2] == (rnd[1] +1) || rnd[2] == rnd[0] || rnd[2] == (rnd[0] - 1) || rnd[2] == (rnd[0] + 1))
    	{
        	rnd[2] = rand() % 35 + 4;
    	}
    gotoxy(rnd[2], 2);
    printf("%s", target[2]);
	count++;
    display_text(count, r_count, score);
    game_control(&r_count, rnd, &score);
   }while(count<10);
   return 0;
}

void intro_game(void)
{
	printf("��Ÿ�� ȭ����\n\n");
	printf("���� Ÿ�� �̵��ϸ鼭 \n");
	printf("��ǥ���� ���ߴ� �����Դϴ�. \n");
	printf("��ȸ�� 10���̸� \n");
	printf("ȭ���� �����̽�Ű�� �߻��մϴ�. \n\n");
	printf("��: 1��, ��: 10��, ��: 100��\n\n");
	printf("�ƹ�Ű�� ������ �����մϴ�. ");
	getch();
}

void horizontal_slide(int x, int y, char *c2)
{
		gotoxy(x, y);
		printf("%s", c2);
		Sleep(50);
		printf("\b ");
}
void draw_rectangle(int r, int c)
{
    int i, j;
    unsigned char a=0xa6;
    unsigned char b[7];
	 
    for(i=1;i<7;i++)
   		b[i]=0xa0+i;

    printf("%c%c",a, b[3]);
    for(i=0;i<c;i++)
  		printf("%c%c", a, b[1]);
    printf("%c%c", a, b[4]);
    printf("\n");
    for(i=0;i<r;i++)
    {
		printf("%c%c", a, b[2]);
		for(j=0;j<c;j++)
			printf(" ");
		printf("%c%c",a, b[2]);
		printf("\n");
    }
    printf("%c%c", a, b[6]);
    for(i=0;i<c;i++)
		printf("%c%c", a, b[1]);
    printf("%c%c", a, b[5]);
    printf("\n");
}
void display_text(int count, int r_count, int score)
{
	gotoxy(46, 2);
	printf("�����̽�Ű�� ������\n");
	gotoxy(46, 3);
	printf("ȭ���� �߻�˴ϴ�.\n");
	gotoxy(46, 5);
	printf("Ƚ�� : %d", count);
	gotoxy(46, 6);
	printf("���� : %d", r_count);
	gotoxy(46, 7);
	printf("���� : %d", score);
}

void game_control(int* r_c, int rnd[3], int *score)
{
	int i=1, k=1, y;
	char *horse="��", chr;
	do
	{
		i+=k;
		if (i>39)
			k=-1;
		else if (i<3)
			k=+1;
		horizontal_slide(i+1, 21, horse);
	}while(!kbhit());
	chr=getch();
	y=21;
	if (chr==32)
	{
		while(y>2)
		{
			y-=1;
			gotoxy(i+1, y);
			printf("��");
			Sleep(50);
			printf("\b  ");
		}
		if (((rnd[0] -2) <=i) && (i<= rnd[0]))
		{
			gotoxy(rnd[0], 2);
			printf("��");
			gotoxy(46, 8);
			printf("1�� �Դϴ�!  ");
			Sleep(50);
			*r_c=*r_c+1;
			*score = *score + 1;
		}
		else if (((rnd[1] -2) <=i) && (i<= rnd[1]))
		{
			gotoxy(rnd[1], 2);
			printf("��");
			gotoxy(46, 8);
			printf("10�� �Դϴ�!  ");
			Sleep(50);
			*r_c=*r_c+1;
			*score = *score + 10;
		}
		else if (((rnd[2] -2) <=i) && (i<= rnd[2]))
		{
			gotoxy(rnd[2], 2);
			printf("��");
			gotoxy(46, 8);
			printf("100�� �Դϴ�!  ");
			Sleep(50);
			*r_c=*r_c+1;
			*score = *score + 100;
		}
		gotoxy(1, 24);
		printf("�ƹ�Ű�� ������ �������� ����˴ϴ�. ");
		getch(); 
	}

}
void gotoxy(int x, int y)
{
   COORD Pos = {x - 1, y - 1};
   SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}
